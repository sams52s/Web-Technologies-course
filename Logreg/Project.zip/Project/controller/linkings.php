<?php 
    include '../includes/links.php';
require '../includes/header.php';
require '../includes/navbar.php'; 
?>